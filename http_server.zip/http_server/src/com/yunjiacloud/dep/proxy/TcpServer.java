package com.yunjiacloud.dep.proxy;

import javax.sql.DataSource;

import com.yunjiacloud.dep.proxy.biz.Const;
import com.yunjiacloud.dep.proxy.biz.DataSourceManager;
import com.yunjiacloud.dep.proxy.impl.RestWebServiceHandler;
import com.yunjiacloud.dep.proxy.impl.SOAPWebServiceHandler;

import io.netty.bootstrap.ServerBootstrap;
import io.netty.channel.ChannelFuture;
import io.netty.channel.ChannelInitializer;
import io.netty.channel.ChannelOption;
import io.netty.channel.ChannelPipeline;
import io.netty.channel.EventLoopGroup;
import io.netty.channel.nio.NioEventLoopGroup;
import io.netty.channel.socket.SocketChannel;
import io.netty.channel.socket.nio.NioServerSocketChannel;
import io.netty.handler.codec.string.StringDecoder;
import io.netty.handler.codec.string.StringEncoder;
import io.netty.util.CharsetUtil;

public class TcpServer {

    public void bind(int port) throws Exception {

        DataSource dataSource = DataSourceManager.createDataSource(null);
        DataSourceManager.setDataSource(dataSource);

        // 配置服务端Nio线程组
        EventLoopGroup bossGroup = new NioEventLoopGroup();
        EventLoopGroup workerGroup = new NioEventLoopGroup();
        try {
            ServerBootstrap b = new ServerBootstrap();
            b.group(bossGroup, workerGroup).channel(NioServerSocketChannel.class).option(ChannelOption.SO_BACKLOG, 1024)
                    .childHandler(new ChildChannelHandler());
            // 绑定端口，同步等待成功
            ChannelFuture f = b.bind(port).sync();
            // 等待服务端监听端口关闭
            f.channel().closeFuture().sync();

        } finally {
            // 退出时释放资源
            bossGroup.shutdownGracefully();
            workerGroup.shutdownGracefully();
        }
    }

    private class ChildChannelHandler extends ChannelInitializer<SocketChannel> {
        @Override
        protected void initChannel(SocketChannel channel) throws Exception {
            ChannelPipeline pipeline = channel.pipeline();
            pipeline.addLast("decoder", new StringDecoder(CharsetUtil.UTF_8));
            pipeline.addLast("encoder", new StringEncoder(CharsetUtil.UTF_8));
            String channelType = System.getProperty(Const.CHANNEL_TYPE_D, Const.WS_TYPE);
            if (Const.WS_TYPE.equals(channelType)) {
                pipeline.addLast(new SOAPWebServiceHandler());
            } else {
                pipeline.addLast(new RestWebServiceHandler());
            }
        }
    }

    public static void main(String[] args) throws Exception {
        int port = 8280;
        new TcpServer().bind(port);
    }
}
