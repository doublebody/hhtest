package com.yunjiacloud.dep.proxy.biz;

import java.sql.ResultSet;
import java.sql.Statement;

import javax.sql.DataSource;


public class TraceLogRecorder {

    public static void saveLog(DataSource dataSource, String name) {
        Statement stmt = null;
        ResultSet rs = null;
        try {

//            stmt = createConnection(dataSource).createStatement();
//            rs = stmt.executeQuery(sql);

            // populate user object
            
        } catch (Exception ex) {
            throw new RuntimeException(ex);
        } finally {
//            closeQuitely(rs);
//            closeQuitely(stmt);
        }
    }
}
